import java.util.ArrayList;

public class Inventory {
	protected ArrayList<Products> allProducts = new ArrayList<Products>();

	public void printCurrentValue(Products p) {
		int sum = 0;
		for(Products i:allProducts) {
			sum+=i.cost;
		}
		System.out.println(sum);
	}

	public void add(Products p) {
		this.allProducts.add(p);
	}

	public void remove(Products p) {
		this.allProducts.remove(p);
	}

	public void removeAll() {
		this.allProducts.clear();
	}

	public void printListOfDefected() {
		int sum = 0;
		for(Products i: allProducts) {
			if(i.status == false) {
				System.out.println("Product name: "+i.productName);
				System.out.println("Cost: "+i.cost);
				sum+= i.cost;
			}
		}
		System.out.println(sum);
	}

	public void printProductType() {
		int m = 0, m1 = 0, k = 0, c = 0;
		for(Products i: allProducts) {
			if(i instanceof Monitors)
				m++;
			if(i instanceof Mouse)
				m1++;
			if(i instanceof Keyboards)
				k++;
			if(i instanceof Computer)
				c++;
		}
		System.out.println(m+" Monitors, "+m1+" Mouses, "+k+" Keyboards, "+c+" Computers.");

	}


}