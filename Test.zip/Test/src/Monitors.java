import java.util.ArrayList;

public class Monitors extends Products{
	protected double inch;
	protected enum Type{
		HDMI, VGA, DVI, DP
	}
	protected ArrayList<Type> allTypes = new ArrayList<Type>();
	

	public Monitors(String productName, double cost, boolean status, double inch, Type[] arr) {
		super(productName, cost, status);
		this.inch = inch;
		for(Type i: arr) {
			allTypes.add(i);
		}
	}
	
	

}
