package part1;

public class Question3 {
	public static int k(int n) {
		if(n==0) {
			return 0;
		}
		return k(n-1)+2;
	}

	public static void main(String[] args) {
		
		System.out.println(k(2));
		
	}
	

}
