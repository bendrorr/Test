package part1;

public class Question1 {
	public static int f(String str, int num) {
		String[] arr = str.split(" ");
		int res=0;
		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arr.length; j++) {
				if(Integer.parseInt(arr[i]) != Integer.parseInt(arr[j])) {
					if(Integer.parseInt(arr[i]+ arr[j])%num == 0 ) {
						System.out.println(Integer.parseInt(arr[i]+ arr[j]));
						res++;
					}
				}
			}
		}
		return res;
	}

	public static void main(String[] args) {
		
		String s = "1 2 3";
		int n =3;
		System.out.println(f(s,n));


	}

}
