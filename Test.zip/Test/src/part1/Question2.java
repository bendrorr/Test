package part1;

public class Question2 {
	
	public static int g(String s) {
		String[] arr = s.split(" ");
		int min = arr[0].length();
		
		for (int i = 1; i < arr.length; i++) {
			if(arr[i].length() < min) {
				min = arr[i].length();
			}
		}
		return min;
	}

	public static void main(String[] args) {
		String s = "writing code is fun";
		System.out.println(g(s));

	}

}
