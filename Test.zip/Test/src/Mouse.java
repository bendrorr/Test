
public class Mouse extends Products{
	protected int workingKeys;
	protected int notWorkingKeys;
	
	public Mouse(String productName, double cost, boolean status, int workingKeys, int notWorkingKeys) {
		super(productName, cost, status);
		this.workingKeys = workingKeys;
		this.notWorkingKeys = notWorkingKeys;
	}

}
