
public class Computer extends Products{
	protected boolean windowsStatus;
	
	public Computer(String productName, double cost, boolean status, boolean windowsStatus) {
		super(productName, cost, status);
		this.windowsStatus = windowsStatus;
		
	}

}
