
public class Products {
	protected String productName;
	protected double cost;
	protected boolean status;
	
	public Products(String productName, double cost, boolean status) {
		this.productName = productName;
		this.cost = cost;
		this.status = status;
	}
}
