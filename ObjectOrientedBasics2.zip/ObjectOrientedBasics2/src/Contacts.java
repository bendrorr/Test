import java.util.Objects;

public class Contacts {
    private String name;
    private String pNumber;

    public Contacts(String name, String pNumber){
        this.name=name;
        this.pNumber=pNumber;

    }

    public String getName() {
        return name;
    }

    public String getpNumber() {
        return pNumber;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contacts contacts = (Contacts) o;
        return Objects.equals(name, contacts.name) && Objects.equals(pNumber, contacts.pNumber);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, pNumber);
    }

    @Override
    public String toString() {
        return "Contacts{" +
                "name='" + name + '\'' +
                ", pNumber='" + pNumber + '\'' +
                '}';
    }


}
