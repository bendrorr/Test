import com.sun.source.tree.PatternTree;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Pattern;

public class Main {

    public static void printMenu(){
        System.out.println("1- Add contact\n" +
                "2- Delete contact by name\n" +
                "3- Print all contacts\n" +
                "4- Find contact by name\n" +
                "5- Sort phone book by name\n" +
                "6- Sort phone book by phone number\n" +
                "7- Reverse order\n" +
                "8- Remove duplicate contacts\n" +
                "9- Saving contacts to file\n" +
                "10- Loading contacts from a file\n" +
                "11- Remove all contacts\n" +
                "12- Exit");
    }
    public static void main(String[] args) throws IOException {

        Scanner s =new Scanner(System.in);
        String fileName="";
        String name="";
        String phoneNumber="";
        int choice;
        int count=0;

        while(count <3){

            try {
                printMenu();
                choice = s.nextInt();


                switch (choice){

                    case 1:
                        System.out.println("Enter new contact name:");
                        name=s.next();
                        System.out.println("Enter new contact phone number:");
                        phoneNumber=s.next();
                        if(!phoneNumber.matches("^[0-9]+$") ){
                            System.out.println("Error adding contact, phone number should only contain digits.");
                            count++;
                        }
                        else if(phoneNumber.length()>10||phoneNumber.length()<10){
                            System.out.println("The length of the phone number is incorrect, ten digits must be entered.");
                            count++;
                        }

                        else {
                            Pbook.addContact((new Contacts(name,phoneNumber)));
                            System.out.println("New contact added: name = "+name+", phone = "+ phoneNumber );
                        }

                        break;

                    case 2:
                        System.out.println("Enter the name of a contact to delete:");
                        name=s.next();
                        Pbook.removeContact(name);
                        break;

                    case 3:
                        Pbook.print();
                        break;

                    case 4:
                        System.out.println("Enter a contact name to search:");
                        name=s.next();
                        Pbook.findByName(name);
                        break;

                    case 5:
                        Pbook.sortByName();
                        break;

                    case 6:
                        Pbook.sortByPhone();
                        break;

                    case 7:
                        Pbook.reverseOrder();
                        break;

                    case 8:
                        Pbook.removeDuplicate();
                        break;

                    case 9:
                        Pbook.writingToFile();
                        break;

                    case 10:
                        System.out.println("Enter file name:");
                        fileName=s.next();
                        Pbook.readingFromFile(fileName);
                        break;

                    case 11:
                        Pbook.clearAll();
                        break;

                    case 12:
                        System.out.println("Bye bye(:");
                        count=3;
                        break;

                    default:
                        count++;
                        if(count==3) System.out.println("Bye bye(:");
                        else
                            System.out.println("Invalid Selection, enter a value between 1 and 12.");
                }
            }catch (Exception e){
                count++;
                if(count==3) System.out.println("Bye bye(:");
                else{
                    System.out.println("Invalid Selection.");
                    s.next();

                }

            }
        }

    }
}