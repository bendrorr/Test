import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.*;

import static java.util.Comparator.*;

public class Pbook {
    public static ArrayList<Contacts> allContacts=new ArrayList<>();
    public static File f = null;
    public static Scanner s = new Scanner(System.in);

    public static void addContact(Contacts c){

        allContacts.add(c);
    }

    public static void removeContact(String name){
        int l= allContacts.size();
        for (Contacts c:allContacts){
            if (c.getName().equals(name)){
                allContacts.remove(c);
                break;
            }
        }
        if (l==allContacts.size()) System.out.println("Contact does not exist");
    }

    public static void print(){
        for (Contacts c:allContacts){
            System.out.println(c);
        }
        System.out.println("********************");
    }
    public static void findByName(String name){
        boolean f=true;
        for (Contacts c:allContacts){
            if(c.getName().equals(name)){
                f=false;
                System.out.println(c);
            }
        }
        if(f) System.out.println("Contact does not exist");
    }

    public static void sortByName(){
        Collections.sort(allContacts, new Comparator<Contacts>() {
            @Override
            public int compare(Contacts o1, Contacts o2) {
                return o1.getName().compareToIgnoreCase(o2.getName());
            }
        });
        print();
    }

    public static void sortByPhone(){
        Collections.sort(allContacts, new Comparator<Contacts>() {
            @Override
            public int compare(Contacts o1, Contacts o2) {
                return o2.getpNumber().compareToIgnoreCase(o1.getpNumber());
            }
        });
        print();
    }

    public static void reverseOrder(){
        print();
        Collections.reverse(allContacts);
        print();
    }

    public static void removeDuplicate(){
        LinkedHashSet<Contacts> lhs =new LinkedHashSet<>();
        HashSet<Contacts> hs = new HashSet<>();
        for (Contacts c:allContacts){
            if (!lhs.contains(c)){
                lhs.add(c);

            }else{
                if(!hs.contains(c)) System.out.println(c+" Remove successfully\n********************");
                hs.add(c);

            }

        }
        allContacts.clear();
        allContacts.addAll(lhs);
        print();
    }

    public static void clearAll(){
        allContacts.clear();
    }

    public static void readingFromFile(String fileName) throws IOException {
        f = new File(fileName+".txt");
        if(!f.exists()) f.createNewFile();

        s = new Scanner(f);

        while(s.hasNextLine()){
            String[] arr= s.nextLine().split("'");
            allContacts.add(new Contacts(arr[1],arr[3]));

        }

    }

    public static void writingToFile() throws FileNotFoundException {

        if (f==null) {
            System.out.println("Enter file name:");
            String fileName=s.next();
            f=new File(fileName+".txt");
        }

        PrintWriter pw =new PrintWriter(f);
        for (Contacts c:allContacts){
            pw.println(c);
        }

        pw.close();

    }



}
